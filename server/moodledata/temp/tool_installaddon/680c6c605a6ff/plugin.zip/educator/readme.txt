Features and Fixes

1. Option to choose between flexible width and Fixed width for site.
2. Option to switch off/on the top left hand side header logo/heading
3. Fixed custom menu design